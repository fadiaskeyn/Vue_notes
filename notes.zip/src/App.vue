<script setup>
import NotesApp from './presentation/NotesApp.vue';
</script>

<template>
  <NotesApp />
</template>
